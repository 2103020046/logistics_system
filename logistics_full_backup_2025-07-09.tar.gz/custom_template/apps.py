from django.apps import AppConfig


class CustomTemplateConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'custom_template'
